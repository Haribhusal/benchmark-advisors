const state = {
  step: "Email",
  email: "",
};

export default state;
