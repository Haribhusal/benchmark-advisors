import React from "react";

const Success = () => {
  return (
    <div>
      <h1>You are done!</h1>
    </div>
  );
};

export default Success;
