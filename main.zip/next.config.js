module.exports = {
  basePath: "",
  images: {
    domains: ["benchmark.promotingnepal.com"],
  },
};
