import React from "react";

const DownloadFile = () => {
  return <div>Download FIle</div>;
};

export default DownloadFile;
